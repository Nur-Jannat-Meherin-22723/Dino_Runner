# DINO RUNNER

DINO RUNNER is a simple 2d platform game made for the first-year project of CSE, DU.

To run the code in ubuntu open the project folder in terminal and type the following command:
g++ final.cpp LTexture.cpp Dino.cpp Cactus.cpp Tree.cpp Diamond.cpp Snake.cpp Ball.cpp Rabbit.cpp -lSDL2 -lSDL2_image -lSDL2_ttf -lSDL2_mixer && ./a.out

Hope you will enjoy it!!😀️

